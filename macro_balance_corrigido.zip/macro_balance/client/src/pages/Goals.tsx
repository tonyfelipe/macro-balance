import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Save, Calculator } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

type Goal = "weight_loss" | "muscle_gain" | "custom";

export default function Goals() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  
  const [goalType, setGoalType] = useState<Goal>("custom");
  const [bodyWeight, setBodyWeight] = useState("");
  const [carbsMultiplier, setCarbsMultiplier] = useState("4"); // Para ganho de massa
  
  const [targetCalories, setTargetCalories] = useState("");
  const [targetProtein, setTargetProtein] = useState("");
  const [targetCarbs, setTargetCarbs] = useState("");
  const [targetFat, setTargetFat] = useState("");
  
  const { data: goals, isLoading } = trpc.goals.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const utils = trpc.useUtils();
  
  const upsertGoals = trpc.goals.upsert.useMutation({
    onSuccess: () => {
      toast.success("Metas salvas com sucesso!");
      utils.goals.get.invalidate();
      setLocation("/");
    },
    onError: () => {
      toast.error("Erro ao salvar metas");
    },
  });
  
  useEffect(() => {
    if (goals) {
      setTargetCalories(goals.targetCalories as string);
      setTargetProtein(goals.targetProtein as string);
      setTargetCarbs(goals.targetCarbs as string);
      setTargetFat(goals.targetFat as string);
    }
  }, [goals]);
  
  const calculateMacros = () => {
    const weight = parseFloat(bodyWeight);
    
    if (isNaN(weight) || weight <= 0) {
      toast.error("Informe um peso corporal válido");
      return;
    }
    
    if (goalType === "custom") {
      toast.error("Selecione um objetivo ou defina manualmente");
      return;
    }
    
    // Proteína: 2g/kg para ambos os objetivos
    const protein = weight * 2;
    
    // Carboidratos
    let carbs = 0;
    if (goalType === "weight_loss") {
      carbs = weight * 2; // 2g/kg para emagrecimento
    } else if (goalType === "muscle_gain") {
      const multiplier = parseFloat(carbsMultiplier);
      carbs = weight * multiplier; // 4-6g/kg para ganho de massa
    }
    
    // Gorduras: 25-30% das calorias totais (usamos 0.8-1g/kg como base)
    const fat = weight * 0.9;
    
    // Calorias totais: Proteína (4 kcal/g) + Carbs (4 kcal/g) + Gordura (9 kcal/g)
    const calories = (protein * 4) + (carbs * 4) + (fat * 9);
    
    setTargetProtein(protein.toFixed(1));
    setTargetCarbs(carbs.toFixed(1));
    setTargetFat(fat.toFixed(1));
    setTargetCalories(calories.toFixed(0));
    
    toast.success("Metas calculadas com sucesso!");
  };
  
  const handleSave = () => {
    if (!targetCalories || !targetProtein || !targetCarbs || !targetFat) {
      toast.error("Preencha todos os campos");
      return;
    }
    
    const calories = parseFloat(targetCalories);
    const protein = parseFloat(targetProtein);
    const carbs = parseFloat(targetCarbs);
    const fat = parseFloat(targetFat);
    
    if (isNaN(calories) || isNaN(protein) || isNaN(carbs) || isNaN(fat)) {
      toast.error("Valores inválidos");
      return;
    }
    
    if (calories <= 0 || protein <= 0 || carbs <= 0 || fat <= 0) {
      toast.error("Todos os valores devem ser maiores que zero");
      return;
    }
    
    upsertGoals.mutate({
      targetCalories: targetCalories,
      targetProtein: targetProtein,
      targetCarbs: targetCarbs,
      targetFat: targetFat,
    });
  };
  
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Metas Diárias</h1>
              <p className="text-sm text-muted-foreground">
                Configure seus objetivos de macronutrientes
              </p>
            </div>
          </div>
        </div>
      </header>
      
      <main className="container py-6 max-w-2xl space-y-6">
        {/* Calculadora de Metas */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Calculadora de Metas
            </CardTitle>
            <CardDescription>
              Calcule suas metas automaticamente baseado no seu peso e objetivo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Qual é o seu objetivo?</Label>
              <RadioGroup value={goalType} onValueChange={(value) => setGoalType(value as Goal)}>
                <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-accent transition-colors">
                  <RadioGroupItem value="weight_loss" id="weight_loss" />
                  <Label htmlFor="weight_loss" className="flex-1 cursor-pointer">
                    <div className="font-semibold">Emagrecimento</div>
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-accent transition-colors">
                  <RadioGroupItem value="muscle_gain" id="muscle_gain" />
                  <Label htmlFor="muscle_gain" className="flex-1 cursor-pointer">
                    <div className="font-semibold">Ganho de Massa Muscular</div>
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-accent transition-colors">
                  <RadioGroupItem value="custom" id="custom" />
                  <Label htmlFor="custom" className="flex-1 cursor-pointer">
                    <div className="font-semibold">Personalizado</div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            {goalType !== "custom" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="bodyWeight">Peso Corporal (kg)</Label>
                  <Input
                    id="bodyWeight"
                    type="number"
                    value={bodyWeight}
                    onChange={(e) => setBodyWeight(e.target.value)}
                    placeholder="Ex: 70"
                  />
                </div>
                
                {goalType === "muscle_gain" && (
                  <div className="space-y-2">
                    <Label htmlFor="carbsMultiplier">Carboidratos por kg</Label>
                    <RadioGroup value={carbsMultiplier} onValueChange={setCarbsMultiplier}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="4" id="carbs4" />
                        <Label htmlFor="carbs4">4g/kg (moderado)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="5" id="carbs5" />
                        <Label htmlFor="carbs5">5g/kg (alto)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="6" id="carbs6" />
                        <Label htmlFor="carbs6">6g/kg (muito alto)</Label>
                      </div>
                    </RadioGroup>
                  </div>
                )}
                
                <Button 
                  className="w-full" 
                  variant="outline"
                  onClick={calculateMacros}
                >
                  <Calculator className="h-4 w-4 mr-2" />
                  Calcular Metas
                </Button>
              </>
            )}
          </CardContent>
        </Card>
        
        {/* Metas Manuais */}
        <Card>
          <CardHeader>
            <CardTitle>Suas Metas Diárias</CardTitle>
            <CardDescription>
              {goalType === "custom" 
                ? "Defina manualmente seus objetivos" 
                : "Revise e ajuste os valores calculados"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="calories">Calorias (kcal)</Label>
              <Input
                id="calories"
                type="number"
                value={targetCalories}
                onChange={(e) => setTargetCalories(e.target.value)}
                placeholder="Ex: 2000"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="protein">Proteína (g)</Label>
              <Input
                id="protein"
                type="number"
                value={targetProtein}
                onChange={(e) => setTargetProtein(e.target.value)}
                placeholder="Ex: 150"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="carbs">Carboidrato (g)</Label>
              <Input
                id="carbs"
                type="number"
                value={targetCarbs}
                onChange={(e) => setTargetCarbs(e.target.value)}
                placeholder="Ex: 200"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="fat">Gordura (g)</Label>
              <Input
                id="fat"
                type="number"
                value={targetFat}
                onChange={(e) => setTargetFat(e.target.value)}
                placeholder="Ex: 70"
              />
            </div>
            
            <div className="pt-4 border-t">
              <div className="bg-muted/50 rounded-lg p-4 space-y-2 text-sm">
                <h4 className="font-semibold">Referências Nutricionais</h4>
                <p className="text-muted-foreground">
                  <strong>Emagrecimento:</strong> 2g proteína/kg • 2g carboidrato/kg
                </p>
                <p className="text-muted-foreground">
                  <strong>Ganho de massa:</strong> 2g proteína/kg • 4-6g carboidrato/kg
                </p>
                <p className="text-muted-foreground mt-2">
                  <strong>Cálculo de calorias:</strong> Proteína e Carboidrato = 4 kcal/g • Gordura = 9 kcal/g
                </p>
              </div>
            </div>
            
            <Button 
              className="w-full" 
              size="lg" 
              onClick={handleSave}
              disabled={upsertGoals.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              Salvar Metas
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
