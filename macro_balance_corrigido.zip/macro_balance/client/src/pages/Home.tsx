import { useState, useMemo, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MacroProgressBar } from "@/components/MacroProgressBar";
import { AddFoodDialog } from "@/components/AddFoodDialog";
import { trpc } from "@/lib/trpc";
import { Plus, Settings, Calendar, Trash2, LogOut, Download } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { usePWA } from "@/hooks/usePWA";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user, loading, isAuthenticated, logout } = useAuth();
  const { isInstallable, installApp } = usePWA();
  const [addFoodOpen, setAddFoodOpen] = useState(false);
  const [selectedDate] = useState(() => new Date());
  
  const utils = trpc.useUtils();
  
  const { data: goals } = trpc.goals.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const { data: dailyTotals } = trpc.meals.getDailyTotals.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );
  
  const { data: meals, refetch: refetchMeals } = trpc.meals.getByDate.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );
  
  const deleteMeal = trpc.meals.delete.useMutation({
    onSuccess: () => {
      toast.success("Refeição removida");
      refetchMeals();
      utils.meals.getDailyTotals.invalidate();
    },
    onError: () => {
      toast.error("Erro ao remover refeição");
    },
  });
  
  const handleFoodAdded = () => {
    refetchMeals();
    utils.meals.getDailyTotals.invalidate();
  };
  
  const handleDeleteMeal = (mealId: number) => {
    if (confirm("Deseja realmente remover esta refeição?")) {
      deleteMeal.mutate({ mealId });
    }
  };
  
  const hasGoals = goals && parseFloat(goals.targetCalories as string) > 0;
  
  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [loading, isAuthenticated, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Macro Balance</h1>
            </div>
            <div className="flex items-center gap-2">
              {isInstallable && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={async () => {
                    const installed = await installApp();
                    if (installed) {
                      toast.success("App instalado com sucesso!");
                    }
                  }}
                  title="Instalar App"
                >
                  <Download className="h-5 w-5" />
                </Button>
              )}
              <Button variant="ghost" size="icon" asChild>
                <Link href="/history">
                  <Calendar className="h-5 w-5" />
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <Link href="/goals">
                  <Settings className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      <main className="container py-6 space-y-6">
        {/* Goals Setup Prompt */}
        {!hasGoals && (
          <Card className="border-primary/50 bg-primary/5">
            <CardHeader>
              <CardTitle>Configure suas metas</CardTitle>
              <CardDescription>
                Defina suas metas diárias de macronutrientes para começar a acompanhar seu progresso
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild>
                <Link href="/goals">
                  <Settings className="h-4 w-4 mr-2" />
                  Definir Metas
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Progress Cards */}
        {hasGoals && dailyTotals && (
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Progresso de Hoje</CardTitle>
                <CardDescription>
                  {new Date().toLocaleDateString("pt-BR", { 
                    weekday: "long", 
                    year: "numeric", 
                    month: "long", 
                    day: "numeric" 
                  })}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <MacroProgressBar
                  label="Calorias"
                  current={dailyTotals.calories}
                  target={parseFloat(goals.targetCalories as string)}
                  unit="kcal"
                  color="calories"
                />
                <MacroProgressBar
                  label="Proteína"
                  current={dailyTotals.protein}
                  target={parseFloat(goals.targetProtein as string)}
                  unit="g"
                  color="protein"
                />
                <MacroProgressBar
                  label="Carboidrato"
                  current={dailyTotals.carbs}
                  target={parseFloat(goals.targetCarbs as string)}
                  unit="g"
                  color="carbs"
                />
                <MacroProgressBar
                  label="Gordura"
                  current={dailyTotals.fat}
                  target={parseFloat(goals.targetFat as string)}
                  unit="g"
                  color="fat"
                />
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Meals List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Refeições de Hoje</CardTitle>
                <CardDescription>
                  {meals?.length || 0} refeição(ões) registrada(s)
                </CardDescription>
              </div>
              <Button onClick={() => setAddFoodOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Adicionar
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {!meals || meals.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>Nenhuma refeição registrada hoje</p>
                <p className="text-sm mt-2">Clique em "Adicionar" para começar</p>
              </div>
            ) : (
              <div className="space-y-4">
                {meals.map((meal) => {
                  const mealTotals = meal.items.reduce(
                    (acc, item) => {
                      if (item.food) {
                        const quantity = parseFloat(item.quantity as string);
                        const multiplier = quantity / 100;
                        return {
                          calories: acc.calories + parseFloat(item.food.caloriesPer100g as string) * multiplier,
                          protein: acc.protein + parseFloat(item.food.proteinPer100g as string) * multiplier,
                          carbs: acc.carbs + parseFloat(item.food.carbsPer100g as string) * multiplier,
                          fat: acc.fat + parseFloat(item.food.fatPer100g as string) * multiplier,
                        };
                      }
                      return acc;
                    },
                    { calories: 0, protein: 0, carbs: 0, fat: 0 }
                  );
                  
                  return (
                    <div key={meal.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{meal.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {new Date(meal.mealDate).toLocaleTimeString("pt-BR", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteMeal(meal.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      
                      <div className="space-y-1">
                        {meal.items.map((item) => (
                          <div key={item.id} className="text-sm flex justify-between">
                            <span>{item.food?.name}</span>
                            <span className="text-muted-foreground">{item.quantity}g</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="grid grid-cols-4 gap-2 pt-2 border-t text-center">
                        <div>
                          <div className="text-xs text-muted-foreground">Calorias</div>
                          <div className="font-semibold text-calories">{mealTotals.calories.toFixed(0)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Proteína</div>
                          <div className="font-semibold text-protein">{mealTotals.protein.toFixed(1)}g</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Carbs</div>
                          <div className="font-semibold text-carbs">{mealTotals.carbs.toFixed(1)}g</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Gordura</div>
                          <div className="font-semibold text-fat">{mealTotals.fat.toFixed(1)}g</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      
      <AddFoodDialog
        open={addFoodOpen}
        onOpenChange={setAddFoodOpen}
        onFoodAdded={handleFoodAdded}
      />
    </div>
  );
}
