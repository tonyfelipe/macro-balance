import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { Link, useLocation } from "wouter";
import { ptBR } from "date-fns/locale";

export default function History() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  const { data: dailyTotals } = trpc.meals.getDailyTotals.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );
  
  const { data: meals } = trpc.meals.getByDate.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );
  
  const { data: goals } = trpc.goals.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const navigateDay = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
    setSelectedDate(newDate);
  };
  
  const isToday = selectedDate.toDateString() === new Date().toDateString();
  
  const calculatePercentage = (current: number, target: number) => {
    return target > 0 ? Math.round((current / target) * 100) : 0;
  };

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }
  
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Histórico</h1>
              <p className="text-sm text-muted-foreground">
                Visualize seu consumo diário de macronutrientes
              </p>
            </div>
          </div>
        </div>
      </header>
      
      <main className="container py-6 space-y-6">
        <div className="grid lg:grid-cols-[350px_1fr] gap-6">
          {/* Calendar Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5" />
                Selecione uma data
              </CardTitle>
              <CardDescription>
                Escolha um dia para ver o histórico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                locale={ptBR}
                className="rounded-md border"
                disabled={(date) => date > new Date()}
              />
            </CardContent>
          </Card>
          
          {/* Daily Summary Section */}
          <div className="space-y-6">
            {/* Date Navigation */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateDay('prev')}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <div className="text-center">
                    <h2 className="text-2xl font-bold">
                      {selectedDate.toLocaleDateString("pt-BR", { 
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                      })}
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      {selectedDate.toLocaleDateString("pt-BR", { weekday: "long" })}
                      {isToday && " • Hoje"}
                    </p>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateDay('next')}
                    disabled={isToday}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Macros Summary */}
            {dailyTotals && (
              <Card>
                <CardHeader>
                  <CardTitle>Resumo de Macronutrientes</CardTitle>
                  <CardDescription>
                    Consumo total do dia selecionado
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Calorias</div>
                      <div className="text-3xl font-bold text-calories">
                        {dailyTotals.calories.toFixed(0)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {goals && `Meta: ${parseFloat(goals.targetCalories as string).toFixed(0)} kcal`}
                      </div>
                      {goals && (
                        <div className="text-xs font-medium">
                          {calculatePercentage(dailyTotals.calories, parseFloat(goals.targetCalories as string))}% da meta
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Proteína</div>
                      <div className="text-3xl font-bold text-protein">
                        {dailyTotals.protein.toFixed(1)}g
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {goals && `Meta: ${parseFloat(goals.targetProtein as string).toFixed(0)}g`}
                      </div>
                      {goals && (
                        <div className="text-xs font-medium">
                          {calculatePercentage(dailyTotals.protein, parseFloat(goals.targetProtein as string))}% da meta
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Carboidrato</div>
                      <div className="text-3xl font-bold text-carbs">
                        {dailyTotals.carbs.toFixed(1)}g
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {goals && `Meta: ${parseFloat(goals.targetCarbs as string).toFixed(0)}g`}
                      </div>
                      {goals && (
                        <div className="text-xs font-medium">
                          {calculatePercentage(dailyTotals.carbs, parseFloat(goals.targetCarbs as string))}% da meta
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Gordura</div>
                      <div className="text-3xl font-bold text-fat">
                        {dailyTotals.fat.toFixed(1)}g
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {goals && `Meta: ${parseFloat(goals.targetFat as string).toFixed(0)}g`}
                      </div>
                      {goals && (
                        <div className="text-xs font-medium">
                          {calculatePercentage(dailyTotals.fat, parseFloat(goals.targetFat as string))}% da meta
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Meals List */}
            <Card>
              <CardHeader>
                <CardTitle>Refeições do Dia</CardTitle>
                <CardDescription>
                  {meals?.length || 0} refeição(ões) registrada(s)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!meals || meals.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <p>Nenhuma refeição registrada neste dia</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {meals.map((meal) => {
                      const mealTotals = meal.items.reduce(
                        (acc, item) => {
                          if (item.food) {
                            const quantity = parseFloat(item.quantity as string);
                            const multiplier = quantity / 100;
                            return {
                              calories: acc.calories + parseFloat(item.food.caloriesPer100g as string) * multiplier,
                              protein: acc.protein + parseFloat(item.food.proteinPer100g as string) * multiplier,
                              carbs: acc.carbs + parseFloat(item.food.carbsPer100g as string) * multiplier,
                              fat: acc.fat + parseFloat(item.food.fatPer100g as string) * multiplier,
                            };
                          }
                          return acc;
                        },
                        { calories: 0, protein: 0, carbs: 0, fat: 0 }
                      );
                      
                      return (
                        <div key={meal.id} className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-semibold">{meal.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {new Date(meal.mealDate).toLocaleTimeString("pt-BR", {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </p>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            {meal.items.map((item) => (
                              <div key={item.id} className="text-sm flex justify-between">
                                <span>{item.food?.name}</span>
                                <span className="text-muted-foreground">{item.quantity}g</span>
                              </div>
                            ))}
                          </div>
                          
                          <div className="grid grid-cols-4 gap-2 pt-2 border-t text-center">
                            <div>
                              <div className="text-xs text-muted-foreground">Calorias</div>
                              <div className="font-semibold text-calories">{mealTotals.calories.toFixed(0)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground">Proteína</div>
                              <div className="font-semibold text-protein">{mealTotals.protein.toFixed(1)}g</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground">Carbs</div>
                              <div className="font-semibold text-carbs">{mealTotals.carbs.toFixed(1)}g</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground">Gordura</div>
                              <div className="font-semibold text-fat">{mealTotals.fat.toFixed(1)}g</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
