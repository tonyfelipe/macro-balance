import { Progress } from "@/components/ui/progress";

interface MacroProgressBarProps {
  label: string;
  current: number;
  target: number;
  unit: string;
  color: "protein" | "carbs" | "fat" | "calories";
}

export function MacroProgressBar({ label, current, target, unit, color }: MacroProgressBarProps) {
  const percentage = target > 0 ? Math.min((current / target) * 100, 100) : 0;
  const remaining = Math.max(target - current, 0);
  
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-foreground">{label}</span>
        <span className="text-muted-foreground">
          {current.toFixed(1)} / {target.toFixed(1)} {unit}
        </span>
      </div>
      
      <div className="relative">
        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
          <div 
            className={`h-full bg-${color} transition-all duration-500 ease-out`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
      
      <div className="flex items-center justify-between text-xs">
        <span className={`text-${color} font-medium`}>
          {percentage.toFixed(0)}%
        </span>
        <span className="text-muted-foreground">
          {remaining > 0 ? `Faltam ${remaining.toFixed(1)}${unit}` : "Meta atingida! 🎉"}
        </span>
      </div>
    </div>
  );
}
