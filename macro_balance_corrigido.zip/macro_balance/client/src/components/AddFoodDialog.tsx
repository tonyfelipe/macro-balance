import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Search, Plus } from "lucide-react";
import { toast } from "sonner";

interface AddFoodDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFoodAdded: () => void;
}

export function AddFoodDialog({ open, onOpenChange, onFoodAdded }: AddFoodDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFood, setSelectedFood] = useState<any>(null);
  const [quantity, setQuantity] = useState("");
  const [mealName, setMealName] = useState("Refeição");
  
  const { data: foods, isLoading } = trpc.foods.search.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length > 0 }
  );
  
  const createMeal = trpc.meals.create.useMutation({
    onSuccess: () => {
      toast.success("Alimento adicionado com sucesso!");
      onFoodAdded();
      onOpenChange(false);
      setSearchQuery("");
      setSelectedFood(null);
      setQuantity("");
      setMealName("Refeição");
    },
    onError: () => {
      toast.error("Erro ao adicionar alimento");
    },
  });
  
  const handleAddFood = () => {
    if (!selectedFood || !quantity) {
      toast.error("Selecione um alimento e informe a quantidade");
      return;
    }
    
    const quantityNum = parseFloat(quantity);
    if (isNaN(quantityNum) || quantityNum <= 0) {
      toast.error("Quantidade inválida");
      return;
    }
    
    createMeal.mutate({
      name: mealName,
      mealDate: new Date(),
      items: [{
        foodId: selectedFood.id,
        quantity: quantity,
      }],
    });
  };
  
  const calculateNutrients = () => {
    if (!selectedFood || !quantity) return null;
    
    const quantityNum = parseFloat(quantity);
    if (isNaN(quantityNum)) return null;
    
    const multiplier = quantityNum / 100;
    
    return {
      calories: (parseFloat(selectedFood.caloriesPer100g) * multiplier).toFixed(1),
      protein: (parseFloat(selectedFood.proteinPer100g) * multiplier).toFixed(1),
      carbs: (parseFloat(selectedFood.carbsPer100g) * multiplier).toFixed(1),
      fat: (parseFloat(selectedFood.fatPer100g) * multiplier).toFixed(1),
    };
  };
  
  const nutrients = calculateNutrients();
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Adicionar Alimento</DialogTitle>
          <DialogDescription>
            Busque um alimento e informe a quantidade consumida
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="mealName">Nome da Refeição</Label>
            <Input
              id="mealName"
              value={mealName}
              onChange={(e) => setMealName(e.target.value)}
              placeholder="Ex: Café da manhã, Almoço..."
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="search">Buscar Alimento</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Digite o nome do alimento..."
              />
            </div>
          </div>
          
          {isLoading && (
            <div className="text-sm text-muted-foreground text-center py-4">
              Buscando...
            </div>
          )}
          
          {foods && foods.length > 0 && !selectedFood && (
            <div className="max-h-[200px] overflow-y-auto space-y-1 border rounded-lg p-2">
              {foods.map((food) => (
                <button
                  key={food.id}
                  onClick={() => setSelectedFood(food)}
                  className="w-full text-left px-3 py-2 rounded-md hover:bg-accent transition-colors"
                >
                  <div className="font-medium">{food.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {food.category} • {food.caloriesPer100g}kcal/100g
                  </div>
                </button>
              ))}
            </div>
          )}
          
          {selectedFood && (
            <div className="space-y-4 border rounded-lg p-4 bg-muted/50">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-medium">{selectedFood.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedFood.category}</div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedFood(null)}
                >
                  Trocar
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantidade (gramas)</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="Ex: 100"
                />
                {selectedFood.servingSize && (
                  <div className="text-xs text-muted-foreground">
                    Sugestão: {selectedFood.servingSize}g ({selectedFood.servingDescription})
                  </div>
                )}
              </div>
              
              {nutrients && (
                <div className="grid grid-cols-2 gap-3 pt-2 border-t">
                  <div>
                    <div className="text-xs text-muted-foreground">Calorias</div>
                    <div className="text-lg font-semibold text-calories">{nutrients.calories} kcal</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Proteína</div>
                    <div className="text-lg font-semibold text-protein">{nutrients.protein}g</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Carboidrato</div>
                    <div className="text-lg font-semibold text-carbs">{nutrients.carbs}g</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Gordura</div>
                    <div className="text-lg font-semibold text-fat">{nutrients.fat}g</div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => onOpenChange(false)}
          >
            Cancelar
          </Button>
          <Button
            className="flex-1"
            onClick={handleAddFood}
            disabled={!selectedFood || !quantity || createMeal.isPending}
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
