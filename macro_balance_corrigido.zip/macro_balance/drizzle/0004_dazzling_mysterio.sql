DROP TABLE `foods`;--> statement-breakpoint
DROP TABLE `mealItems`;--> statement-breakpoint
DROP TABLE `meals`;--> statement-breakpoint
DROP TABLE `userGoals`;--> statement-breakpoint
DROP TABLE `users`;