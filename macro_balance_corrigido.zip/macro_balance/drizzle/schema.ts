import { integer, pgEnum, pgTable, text, timestamp, varchar, numeric, index } from "drizzle-orm/pg-core";

/**
 * Enums
 */
export const roleEnum = pgEnum("role", ["user", "admin"]);

/**
 * Core user table backing auth flow.
 */
export const users = pgTable("users", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  openId: varchar("openId", { length: 64 }).unique(), // Opcional para compatibilidade OAuth
  name: text("name"),
  email: varchar("email", { length: 320 }).notNull().unique(),
  password: varchar("password", { length: 255 }), // Hash bcrypt da senha
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: roleEnum("role").default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Alimentos com informações nutricionais por 100g
 */
export const foods = pgTable("foods", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("userId").references(() => users.id, { onDelete: "cascade" }), // null = alimento padrão, não-null = alimento personalizado
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  // Valores nutricionais por 100g
  caloriesPer100g: numeric("caloriesPer100g", { precision: 8, scale: 2 }).notNull(),
  proteinPer100g: numeric("proteinPer100g", { precision: 8, scale: 2 }).notNull(),
  carbsPer100g: numeric("carbsPer100g", { precision: 8, scale: 2 }).notNull(),
  fatPer100g: numeric("fatPer100g", { precision: 8, scale: 2 }).notNull(),
  // Porção padrão (opcional)
  servingSize: numeric("servingSize", { precision: 8, scale: 2 }), // em gramas
  servingDescription: varchar("servingDescription", { length: 100 }), // ex: "1 xícara", "1 unidade média"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  nameIdx: index("name_idx").on(table.name),
}));

export type Food = typeof foods.$inferSelect;
export type InsertFood = typeof foods.$inferInsert;

/**
 * Metas diárias de macronutrientes por usuário
 */
export const userGoals = pgTable("userGoals", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  targetCalories: numeric("targetCalories", { precision: 8, scale: 2 }).notNull(),
  targetProtein: numeric("targetProtein", { precision: 8, scale: 2 }).notNull(),
  targetCarbs: numeric("targetCarbs", { precision: 8, scale: 2 }).notNull(),
  targetFat: numeric("targetFat", { precision: 8, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("user_idx").on(table.userId),
}));

export type UserGoal = typeof userGoals.$inferSelect;
export type InsertUserGoal = typeof userGoals.$inferInsert;

/**
 * Refeições registradas pelo usuário
 */
export const meals = pgTable("meals", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(), // ex: "Café da manhã", "Almoço", "Lanche"
  mealDate: timestamp("mealDate").notNull(), // data/hora da refeição
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userDateIdx: index("user_date_idx").on(table.userId, table.mealDate),
}));

export type Meal = typeof meals.$inferSelect;
export type InsertMeal = typeof meals.$inferInsert;

/**
 * Itens individuais de cada refeição (alimento + quantidade)
 */
export const mealItems = pgTable("mealItems", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  mealId: integer("mealId").notNull().references(() => meals.id, { onDelete: "cascade" }),
  foodId: integer("foodId").notNull().references(() => foods.id, { onDelete: "cascade" }),
  quantity: numeric("quantity", { precision: 8, scale: 2 }).notNull(), // quantidade em gramas
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  mealIdx: index("meal_idx").on(table.mealId),
}));

export type MealItem = typeof mealItems.$inferSelect;
export type InsertMealItem = typeof mealItems.$inferInsert;
