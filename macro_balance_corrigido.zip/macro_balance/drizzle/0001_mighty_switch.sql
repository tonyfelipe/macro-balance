CREATE TABLE `foods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(100),
	`caloriesPer100g` decimal(8,2) NOT NULL,
	`proteinPer100g` decimal(8,2) NOT NULL,
	`carbsPer100g` decimal(8,2) NOT NULL,
	`fatPer100g` decimal(8,2) NOT NULL,
	`servingSize` decimal(8,2),
	`servingDescription` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `foods_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mealId` int NOT NULL,
	`foodId` int NOT NULL,
	`quantity` decimal(8,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mealItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`mealDate` timestamp NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `meals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userGoals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`targetCalories` decimal(8,2) NOT NULL,
	`targetProtein` decimal(8,2) NOT NULL,
	`targetCarbs` decimal(8,2) NOT NULL,
	`targetFat` decimal(8,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userGoals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `mealItems` ADD CONSTRAINT `mealItems_mealId_meals_id_fk` FOREIGN KEY (`mealId`) REFERENCES `meals`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mealItems` ADD CONSTRAINT `mealItems_foodId_foods_id_fk` FOREIGN KEY (`foodId`) REFERENCES `foods`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `meals` ADD CONSTRAINT `meals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userGoals` ADD CONSTRAINT `userGoals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `name_idx` ON `foods` (`name`);--> statement-breakpoint
CREATE INDEX `meal_idx` ON `mealItems` (`mealId`);--> statement-breakpoint
CREATE INDEX `user_date_idx` ON `meals` (`userId`,`mealDate`);--> statement-breakpoint
CREATE INDEX `user_idx` ON `userGoals` (`userId`);