import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { SignJWT } from "jose";
import { ENV } from "./_core/env";

const JWT_SECRET = new TextEncoder().encode(ENV.jwtSecret || "your-secret-key-change-in-production");

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    register: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6),
        name: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Check if user already exists
        const existing = await db.getUserByEmail(input.email);
        if (existing) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Email já cadastrado",
          });
        }

        const user = await db.createUser(input.email, input.password, input.name);

        // Create JWT token
        const token = await new SignJWT({ userId: user.insertId })
          .setProtectedHeader({ alg: "HS256" })
          .setIssuedAt()
          .setExpirationTime("30d")
          .sign(JWT_SECRET);

        // Set cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, cookieOptions);

        return { success: true };
      }),
    
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.verifyUser(input.email, input.password);
        
        if (!user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Email ou senha inválidos",
          });
        }

        // Create JWT token
        const token = await new SignJWT({ userId: user.id })
          .setProtectedHeader({ alg: "HS256" })
          .setIssuedAt()
          .setExpirationTime("30d")
          .sign(JWT_SECRET);

        // Set cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, cookieOptions);

        return { success: true };
      }),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  foods: router({
    search: protectedProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        return await db.searchFoods(input.query);
      }),
    
    list: protectedProcedure
      .query(async () => {
        return await db.getAllFoods();
      }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getFoodById(input.id);
      }),
  }),

  goals: router({
    get: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getUserGoal(ctx.user.id);
      }),
    
    upsert: protectedProcedure
      .input(z.object({
        targetCalories: z.string(),
        targetProtein: z.string(),
        targetCarbs: z.string(),
        targetFat: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.upsertUserGoal(ctx.user.id, input);
        return { success: true };
      }),
  }),

  meals: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        mealDate: z.date(),
        notes: z.string().optional(),
        items: z.array(z.object({
          foodId: z.number(),
          quantity: z.string(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const mealId = await db.createMeal(
          ctx.user.id,
          {
            name: input.name,
            mealDate: input.mealDate,
            notes: input.notes || null,
          },
          input.items
        );
        
        return { success: true, mealId };
      }),
    
    getByDate: protectedProcedure
      .input(z.object({
        date: z.date(),
      }))
      .query(async ({ ctx, input }) => {
        return await db.getMealsByDate(ctx.user.id, input.date);
      }),
    
    getDailyTotals: protectedProcedure
      .input(z.object({
        date: z.date(),
      }))
      .query(async ({ ctx, input }) => {
        return await db.getDailyTotals(ctx.user.id, input.date);
      }),
    
    delete: protectedProcedure
      .input(z.object({ mealId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteMeal(input.mealId, ctx.user.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
