import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

function createMockContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      cookie: () => {},
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Local Authentication", () => {
  it("should register a new user", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test${Date.now()}@example.com`;

    const result = await caller.auth.register({
      email: testEmail,
      password: "test123456",
      name: "Test User",
    });

    expect(result).toEqual({ success: true });

    // Verify user was created
    const user = await db.getUserByEmail(testEmail);
    expect(user).toBeDefined();
    expect(user?.email).toBe(testEmail);
    expect(user?.name).toBe("Test User");
    expect(user?.password).toBeDefined(); // Should have hashed password
  });

  it("should not allow duplicate email registration", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `duplicate${Date.now()}@example.com`;

    // Register first time
    await caller.auth.register({
      email: testEmail,
      password: "test123456",
    });

    // Try to register again with same email
    await expect(
      caller.auth.register({
        email: testEmail,
        password: "different",
      })
    ).rejects.toThrow();
  });

  it("should login with correct credentials", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `login${Date.now()}@example.com`;
    const testPassword = "mypassword123";

    // Register user
    await caller.auth.register({
      email: testEmail,
      password: testPassword,
    });

    // Login
    const result = await caller.auth.login({
      email: testEmail,
      password: testPassword,
    });

    expect(result).toEqual({ success: true });
  });

  it("should reject login with wrong password", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `wrongpass${Date.now()}@example.com`;

    // Register user
    await caller.auth.register({
      email: testEmail,
      password: "correctpassword",
    });

    // Try to login with wrong password
    await expect(
      caller.auth.login({
        email: testEmail,
        password: "wrongpassword",
      })
    ).rejects.toThrow();
  });

  it("should reject login with non-existent email", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.login({
        email: "nonexistent@example.com",
        password: "anypassword",
      })
    ).rejects.toThrow();
  });
});
