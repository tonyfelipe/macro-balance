import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("goals procedures", () => {
  it("should upsert user goals", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.goals.upsert({
      targetCalories: "2000",
      targetProtein: "150",
      targetCarbs: "200",
      targetFat: "70",
    });

    expect(result.success).toBe(true);
  });

  it("should get user goals", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // First set goals
    await caller.goals.upsert({
      targetCalories: "2000",
      targetProtein: "150",
      targetCarbs: "200",
      targetFat: "70",
    });

    const result = await caller.goals.get();

    expect(result).toBeDefined();
    if (result) {
      expect(result.targetCalories).toBe("2000.00");
      expect(result.targetProtein).toBe("150.00");
    }
  });
});

describe("meals procedures", () => {
  it("should create meal with items", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Get a food to add
    const foods = await caller.foods.list();
    expect(foods.length).toBeGreaterThan(0);
    const firstFood = foods[0]!;

    const result = await caller.meals.create({
      name: "Café da manhã",
      mealDate: new Date(),
      items: [
        {
          foodId: firstFood.id,
          quantity: "100",
        },
      ],
    });

    expect(result.success).toBe(true);
    expect(result.mealId).toBeDefined();
  });

  it("should get meals by date", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const today = new Date();
    const result = await caller.meals.getByDate({ date: today });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should calculate daily totals", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const today = new Date();
    const result = await caller.meals.getDailyTotals({ date: today });

    expect(result).toBeDefined();
    expect(result).toHaveProperty("calories");
    expect(result).toHaveProperty("protein");
    expect(result).toHaveProperty("carbs");
    expect(result).toHaveProperty("fat");
    expect(typeof result.calories).toBe("number");
    expect(typeof result.protein).toBe("number");
  });

  it("should delete meal", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // First create a meal
    const foods = await caller.foods.list();
    const firstFood = foods[0]!;

    const created = await caller.meals.create({
      name: "Test meal",
      mealDate: new Date(),
      items: [
        {
          foodId: firstFood.id,
          quantity: "100",
        },
      ],
    });

    expect(created.mealId).toBeDefined();

    // Now delete it
    const result = await caller.meals.delete({ mealId: created.mealId! });

    expect(result.success).toBe(true);
  });
});
