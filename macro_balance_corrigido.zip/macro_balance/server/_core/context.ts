import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { jwtVerify } from "jose";
import cookie from "cookie";
import { COOKIE_NAME } from "@shared/const";
import { ENV } from "./env";
import * as db from "../db";

const JWT_SECRET = new TextEncoder().encode(ENV.jwtSecret);

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    const cookies = cookie.parse(opts.req.headers.cookie || "");
    const token = cookies[COOKIE_NAME];

    if (token) {
      const { payload } = await jwtVerify(token, JWT_SECRET);
      const userId = payload.userId as number;

      if (userId) {
        const foundUser = await db.getUserById(userId);
        if (foundUser) {
          user = foundUser;
        }
      }
    }
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
