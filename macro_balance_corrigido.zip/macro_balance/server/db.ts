import { eq, and, desc, sql, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pkg from 'pg';
const { Pool } = pkg;
import { InsertUser, users, foods, userGoals, meals, mealItems, InsertMeal, InsertMealItem, InsertUserGoal } from "../drizzle/schema";
import bcrypt from "bcryptjs";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== AUTH FUNCTIONS ====================

export async function createUser(email: string, password: string, name?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  const [user] = await db.insert(users).values({
    email,
    password: hashedPassword,
    name: name || null,
    loginMethod: "local",
  });

  return user;
}

export async function verifyUser(email: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

  if (!user || !user.password) {
    return null;
  }

  const isValid = await bcrypt.compare(password, user.password);
  if (!isValid) {
    return null;
  }

  // Update last signed in
  await db.update(users)
    .set({ lastSignedIn: new Date() })
    .where(eq(users.id, user.id));

  return user;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return user;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return user;
}

// ==================== FOODS FUNCTIONS ====================

export async function searchFoods(query: string) {
  const db = await getDb();
  if (!db) return [];

  const results = await db
    .select()
    .from(foods)
    .where(sql`${foods.name} LIKE ${`%${query}%`}`)
    .limit(20);

  return results;
}

export async function getAllFoods() {
  const db = await getDb();
  if (!db) return [];

  const results = await db.select().from(foods).orderBy(foods.name);
  return results;
}

export async function getFoodById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const [food] = await db.select().from(foods).where(eq(foods.id, id)).limit(1);
  return food;
}

// ==================== GOALS FUNCTIONS ====================

export async function upsertUserGoal(userId: number, goal: Omit<InsertUserGoal, "userId">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(userGoals)
    .where(eq(userGoals.userId, userId))
    .limit(1);

  if (existing.length > 0) {
    await db
      .update(userGoals)
      .set({
        targetCalories: goal.targetCalories,
        targetProtein: goal.targetProtein,
        targetCarbs: goal.targetCarbs,
        targetFat: goal.targetFat,
        updatedAt: new Date(),
      })
      .where(eq(userGoals.userId, userId));
  } else {
    await db.insert(userGoals).values({
      userId,
      ...goal,
    });
  }
}

export async function getUserGoal(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const [goal] = await db
    .select()
    .from(userGoals)
    .where(eq(userGoals.userId, userId))
    .limit(1);

  return goal;
}

// ==================== MEALS FUNCTIONS ====================

export async function createMeal(userId: number, mealData: Omit<InsertMeal, "userId">, items: Array<Omit<InsertMealItem, "mealId">>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(meals).values({
    userId,
    ...mealData,
  });

  const mealId = result.insertId;

  if (items.length > 0) {
    await db.insert(mealItems).values(
      items.map((item) => ({
        mealId,
        ...item,
      }))
    );
  }

  return mealId;
}

export async function getMealsByDate(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];

  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  const results = await db
    .select()
    .from(meals)
    .where(
      and(
        eq(meals.userId, userId),
        gte(meals.mealDate, startOfDay),
        lte(meals.mealDate, endOfDay)
      )
    )
    .orderBy(desc(meals.mealDate));

  // Get items for each meal
  const mealsWithItems = await Promise.all(
    results.map(async (meal) => {
      const items = await db
        .select()
        .from(mealItems)
        .where(eq(mealItems.mealId, meal.id));

      const itemsWithFood = await Promise.all(
        items.map(async (item) => {
          const food = await getFoodById(item.foodId);
          return { ...item, food };
        })
      );

      return { ...meal, items: itemsWithFood };
    })
  );

  return mealsWithItems;
}

export async function deleteMeal(mealId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(meals).where(and(eq(meals.id, mealId), eq(meals.userId, userId)));
}

export async function getDailyTotals(userId: number, date: Date) {
  const mealsWithItems = await getMealsByDate(userId, date);

  let totalCalories = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;

  for (const meal of mealsWithItems) {
    for (const item of meal.items) {
      if (item.food) {
        const quantity = parseFloat(item.quantity as string);
        const multiplier = quantity / 100;

        totalCalories += parseFloat(item.food.caloriesPer100g as string) * multiplier;
        totalProtein += parseFloat(item.food.proteinPer100g as string) * multiplier;
        totalCarbs += parseFloat(item.food.carbsPer100g as string) * multiplier;
        totalFat += parseFloat(item.food.fatPer100g as string) * multiplier;
      }
    }
  }

  return {
    calories: totalCalories,
    protein: totalProtein,
    carbs: totalCarbs,
    fat: totalFat,
  };
}
